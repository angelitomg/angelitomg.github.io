#!/bin/bash

######################
# SimpleLog v1.0
# Angelito M. Goulart
######################

watch tail -n 20 $1
