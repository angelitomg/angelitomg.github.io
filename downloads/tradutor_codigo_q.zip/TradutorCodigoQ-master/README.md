Tradutor de Código Q
===============

Tradutor utilizado para traduzir o significado dos principais códigos Q utilizados em comunicações.

Uso
---------------

Basta abrir o arquivo, digitar o código desejado e a resposta aparecerá na tela. 

Licença
---------------

Este software é distribuído sem qualquer garantia e pode ser utilizado, modificado e redistribuído sem qualquer restrição.

Autor
---------------

Angelito M. Goulart  
<angelito@bsd.com.br>