<?php
session_start();
if(!(isset($_SESSION['usuario'])) && !(isset($_SESSION['senha'])))
{
	header("location: login.php");
}
session_destroy();
header("location: ../index.php");
?>