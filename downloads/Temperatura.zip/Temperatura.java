import javax.swing.*;
public class Temperatura{
	public static void main(String[] args){
		float resultado = 0.0f;
		String temp;
		float celsius;
		temp = JOptionPane.showInputDialog("Digite uma temperatura em celsius: ");
		celsius = Float.parseFloat(temp);
		resultado = (9 * (float) celsius + 160) / 5;
		JOptionPane.showMessageDialog(null, "A temperatura em Farenheit e: " + resultado + " �F");
	}
}