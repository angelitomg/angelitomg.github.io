<?php
	function getPaises(){
		$paises = array('Brasil', 'China', 'Costa Rica', 'Dinamarca', 'Egito');
		$dados = array();
		for ($i = 0; $i < sizeof($paises); $i++){
			$dados[] = $paises[$i];
		}
		return $dados;
	}

	foreach (getPaises() as $pais) {
		echo "<p>{$pais}</p>";
	}	

?>