<?php
/***** Envio de email *****/
$destinatario = "seu_email@provedor.com";
$assunto = $_POST['assunto'];
$mensagem = "Nome: " . $_POST['nome'] . "\n";
$mensagem .= "Email: ". $_POST['email'] . "\n";
$mensagem .= $_POST['mensagem'];
$header = "MIME-Version: 1.1\n";
$header .= "Content-type: text/plain; charset=iso-8859-1\n";
$header .= "From: email@dominio.com\n";
$header .= "Return-Path: email@dominio.com\n";
if (mail($destinatario, $assunto, $mensagem, $header))
{
	echo "<p style=\"text-align: center; font-family: arial, verdana, sans-serif;\">Email enviado com sucesso!</p>";
	echo "<p style=\"text-align: center;\"><a href=\"index.php\">&lt;&lt; Voltar</a></p>";
}
else
{
	echo "<p style=\"text-align: center; font-family: arial, verdana, sans-serif;\">Falha ao enviar email. Tente novamente mais tarde.</p>";
	echo "<p style=\"text-align: center;\"><a href=\"index.php\">&lt;&lt; Voltar</a></p>";
}

?>