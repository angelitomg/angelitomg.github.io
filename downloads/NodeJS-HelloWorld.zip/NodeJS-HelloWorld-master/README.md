NodeJS Hello World
==============

A simple hello world example written using node.js