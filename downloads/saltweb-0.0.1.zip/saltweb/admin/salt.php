<?php
/*
* SaltWEB
* Angelito M. Goulart
* salt.php
* Arquivo que contem funcoes importantes
* para o funcionamento do SaltWEB
*/

require "config.php";
/***** declaracao das variaveis globais *****/
$id_pagina = '';
$nome_pagina = '';
$titulo_pagina = '';
$keywords_pagina = '';
$descricao_pagina = '';
$conteudo_pagina = '';

/***** funcao para exibir as paginas cadastradas *****/
function exibePaginas()
{
	$consulta = mysql_query("SELECT id, nome, titulo FROM paginas ORDER BY id");
	$strhtml = "<table width=\"80%\" class=\"bordasimples\">";
	$strhtml .= "<tr>";
	$strhtml .= "<td><p class=\"negrito\">Id</p></td>";
	$strhtml .= "<td><p class=\"negrito\">Nome</p></td>";
	$strhtml .= "<td><p class=\"negrito\">T&iacute;tulo</p></td>";
	$strhtml .= "<td><p class=\"negrito\">Op&ccedil;&otilde;es</p></td>";
	$strhtml .= "</tr>";
	while($pagina = mysql_fetch_array($consulta))
	{
	 $strhtml .= "<tr>";
	 $strhtml .= "<td>" . $pagina['id'] . "</td>";
	 $strhtml .= "<td>" . $pagina['nome'] . "</td>";
	 $strhtml .= "<td>" . $pagina['titulo'] . "</td>";
	 $strhtml .= "<td width=\"20%\">" . "<a href=\"editar_pagina.php?pag=" . $pagina['id'] . "\">Editar</a> ";
	 $strhtml .= " <a href=\"excluir_pagina.php?pag=" . $pagina['id'] . "\">Remover</a>" . "</td>";
	 $strhtml .= "</tr>";
	}
	$strhtml .= "</table>";
	return $strhtml;
}

/***** funcao para gerar o menu do painel administrativo *****/
function menuAdmin()
{
	$strmenu = "<table>";
	$strmenu .= "<tr>";
	$strmenu .= "<td width=\"30%\" rowspan=2><img src=\"saltweb.jpg\" alt=\"saltweb\" /></td>";
	$strmenu .= "<td valign=\"top\" width=\"70%\"></td>";
	$strmenu .= "</tr>";
	$strmenu .= "<tr>";
	$strmenu .= "<td>";
	$strmenu .= "<a href=\"../index.php\">Site</a> | ";
	$strmenu .= "<a href=\"paginas.php\">P&aacute;ginas</a> | ";
	$strmenu .= "<a href=\"configuracoes.php\">Configura&ccedil;&otilde;es</a> | ";
	$strmenu .= "<a href=\"logout.php\">Logout</a>";
	$strmenu .= "</td>";
	$strmenu .= "</tr>";
	$strmenu .= "</table>";
	return $strmenu;
}

/***** gera o rodape do painel de administracao *****/
function rodapeAdmin()
{
	$strrodape = "<p><hr />";
	$strrodape .= "<span class=\"small\">SaltWEB - Powered By OrkaDev</span></p>";
	return $strrodape;
}

/***** funcao para consultar dados de uma pagina *****/
function consultarPagina()
{
	global $id_pagina;
	global $nome_pagina;
	global $titulo_pagina;
	global $keywords_pagina;
	global $descricao_pagina;
	global $conteudo_pagina;
	if (!$_GET['pag'] || !is_numeric($_GET['pag']))
	{
		redirecionar();
	}
	$pag = $_GET['pag'];
	$consulta_pagina = mysql_query("SELECT * FROM paginas WHERE id=$pag");
	if (mysql_num_rows($consulta_pagina) == 0)
	{
		redirecionar();
	}
	while($pagina = mysql_fetch_array($consulta_pagina))
	{
		 $id_pagina = $pagina['id'];
		 $nome_pagina = $pagina['nome'];
		 $titulo_pagina = $pagina['titulo'];
		 $keywords_pagina = $pagina['keywords'];
		 $descricao_pagina = $pagina['descricao'];
		 $conteudo_pagina = $pagina['conteudo'];
	}
}

/***** funcao que retorna o titulo do site *****/
function consultarTitulo()
{
	$consulta_titulo = mysql_query("SELECT titulo from configuracoes");
	$titulo_site = mysql_fetch_row($consulta_titulo);
	return $titulo_site[0];
}

/***** funcao utilizada para redirecionamento *****/
function redirecionar()
{
	header("location: paginas.php");
	die();
}
?>