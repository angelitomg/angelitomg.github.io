<?php
require "motor.php";
carregaPagina();
?>
<html>
<head>
<link href="style.css" rel="STYLESHEET" type="text/css" />
<?php
	echo geraMeta();
?>
<title>
<?php 
	echo consultarTitulo();
	echo " - ";
	echo $pg_titulo;
?>
</title>
</head>
<body>
<div id="principal">
<?php
	echo geraTopoSite();
	echo geraMenuSite();
	echo $pg_conteudo;
	echo geraRodapeSite();
?>
</div>
</body>
</html>