<?php
/*
* SaltWEB
* Angelito M. Goulart
* corebd.php
* Arquivo que contem funcoes para manipulacao
* do banco de dados.
*/
require "autentica.php";
require "salt.php";
if (!isset($_GET['op']) || !is_numeric($_GET['op']))
{
	redirecionar();	
}
require "config.php";
$op = $_GET['op'];
switch($op)
{
	case 1:
	{
		adicionarPagina();
		break;
	}
	case 2:
	{
		editarPagina();
		break;
	}
	case 3:
	{
		excluirPagina();
		break;
	}
	case 4:
	{
		alterarTitulo();
		break;
	}
	case 5:
	{
		alterarSenha();
	}
	default:
	{
		redirecionar();
		break;
	}
}

/***** funcao para adicionar uma nova pagina *****/
function adicionarPagina()
{
	if(!$_POST)
	{
		redirecionar();
	}
	$nome = str_replace(' ', '', $_POST['nome']);
	$titulo = $_POST['titulo'];
	$keywords = $_POST['keywords'];
	$conteudo = $_POST['conteudo'];
	$descricao = $_POST['descricao'];
	if (empty($nome) || empty($titulo) || empty($keywords) || empty($descricao) || empty($conteudo))
	{
		echo "<p style=\"text-align: center; color:#FF0000; font-weight: bold; font-family: arial, verdana, sans-serif; \">Preencha corretamente todos os campos.</p>";
		echo "<p style=\"text-align: center;\"><a href=\"adicionar_pagina.php\">&lt;&lt; Voltar</a></p>";
		die();
	}
	$sql_insert = "INSERT INTO paginas (nome, titulo, keywords, descricao, conteudo) VALUES ('$nome', '$titulo', '$keywords', '$descricao', '$conteudo')";
	if (mysql_query($sql_insert))
	{
		echo "<p style=\"text-align: center; font-weight: bold; font-family: arial, verdana, sans-serif; \">P&aacute;gina cadastrada com sucesso!</p>";
		echo "<p style=\"text-align: center;\"><a href=\"paginas.php\">&lt;&lt; Voltar</a></p>";
		die();
	}
	else
	{
		echo "<p style=\"text-align: center; font-weight: bold; font-family: arial, verdana, sans-serif; \">Erro ao cadastrar p&aacute;gina. Tente novamente mais tarde!</p>";
		echo "<p style=\"text-align: center;\"><a href=\"adicionar_pagina.php\">&lt;&lt; Voltar</a></p>";
		die();
	}
}

/***** funcao para excluir uma pagina *****/
function excluirPagina()
{
	if(!$_GET['pag'] || !is_numeric($_GET['pag']))
	{
		redirecionar();
	}
	$pagina = $_GET['pag'];
	$sql_consulta_exclusao = "SELECT * FROM paginas WHERE id=$pagina";
	if (mysql_num_rows(mysql_query($sql_consulta_exclusao)) == 0)
	{
		redirecionar();
	}
	$sql_delete = "DELETE FROM paginas WHERE id=$pagina";
	if (mysql_query($sql_delete))
	{
		echo "<p style=\"text-align: center; font-weight: bold; font-family: arial, verdana, sans-serif; \">P&aacute;gina excluida com sucesso!</p>";
		echo "<p style=\"text-align: center;\"><a href=\"paginas.php\">&lt;&lt; Voltar</a></p>";
	}
	else
	{
		echo "<p style=\"text-align: center; font-weight: bold; font-family: arial, verdana, sans-serif; \">Erro ao excluir p&aacute;gina. Tente novamente mais tarde!</p>";
		echo "<p style=\"text-align: center;\"><a href=\"pagians.php\">&lt;&lt; Voltar</a></p>";
	}
}

/***** funcao para editar pagina *****/
function editarPagina()
{
	if(!$_GET['pag'] || !$_POST || !is_numeric($_GET['pag']))
	{
		redirecionar();
	}
	$pagina = $_GET['pag'];
	$sql_consulta_pagina = "SELECT * FROM paginas WHERE id=$pagina";
	if (mysql_num_rows(mysql_query($sql_consulta_pagina)) == 0)
	{
		redirecionar();
	}
	$nome = str_replace(' ', '', $_POST['nome']);
	$titulo = $_POST['titulo'];
	$keywords = $_POST['keywords'];
	$conteudo = $_POST['conteudo'];
	$descricao = $_POST['descricao'];
	if (empty($nome) || empty($titulo) || empty($keywords) || empty($descricao) || empty($conteudo))
	{
		echo "<p style=\"text-align: center; color:#FF0000; font-weight: bold; font-family: arial, verdana, sans-serif; \">Preencha corretamente todos os campos.</p>";
		echo "<p style=\"text-align: center;\"><a href=\"adicionar_pagina.php\">&lt;&lt; Voltar</a></p>";
		die();
	}
	$sql_update = "UPDATE paginas SET nome = '$nome', titulo = '$titulo', keywords = '$keywords', descricao = '$descricao', conteudo = '$conteudo' WHERE id=$pagina";
	if (mysql_query($sql_update))
	{
		echo "<p style=\"text-align: center; font-weight: bold; font-family: arial, verdana, sans-serif; \">P&aacute;gina alterada com sucesso!</p>";
		echo "<p style=\"text-align: center;\"><a href=\"paginas.php\">&lt;&lt; Voltar</a></p>";
		die();
	}
	else
	{
		echo "<p style=\"text-align: center; font-weight: bold; font-family: arial, verdana, sans-serif; \">Erro ao alterar p&aacute;gina. Tente novamente mais tarde!</p>";
		echo "<p style=\"text-align: center;\"><a href=\"paginas.php\">&lt;&lt; Voltar</a></p>";
		die();
	}
}

/***** funcao para alterar o titulo do site *****/
function alterarTitulo()
{
	if (!$_POST['titulo'])
	{
		redirecionar();
	}
	$titulo = $_POST['titulo'];
	$sql_update_titulo = "UPDATE configuracoes SET titulo = '$titulo'";
	if (mysql_query($sql_update_titulo))
	{
		echo "<p style=\"text-align: center; font-weight: bold; font-family: arial, verdana, sans-serif; \">T&iacute;tulo alterado com sucesso!</p>";
		echo "<p style=\"text-align: center;\"><a href=\"paginas.php\">&lt;&lt; Voltar</a></p>";
		die();
	}
	else
	{
		echo "<p style=\"text-align: center; font-weight: bold; font-family: arial, verdana, sans-serif; \">T&iacute;tulo alterado com sucesso!</p>";
		echo "<p style=\"text-align: center;\"><a href=\"paginas.php\">&lt;&lt; Voltar</a></p>";
		die();
	}
}

/**** alterar a senha do administrador *****/
function alterarSenha()
{
	if(!$_POST)
	{
		redirecionar();
	}
	if ($_POST['senha_nova'] !== $_POST['senha_nova2'])
	{
		echo "<p style=\"text-align: center; font-weight: bold; font-family: arial, verdana, sans-serif; \">As senha digitadas n&atilde;o s&atilde;o iguais.</p>";
		echo "<p style=\"text-align: center;\"><a href=\"paginas.php\">&lt;&lt; Voltar</a></p>";
		die();
	}
	$senha_atual = $_POST['senha_atual'];
	$senha_nova = $_POST['senha_nova'];
	if (strlen($senha_nova) < 3)
	{
		echo "<p style=\"text-align: center; font-weight: bold; font-family: arial, verdana, sans-serif; \">A senha deve ter pelo menos 3 caracteres.</p>";
		echo "<p style=\"text-align: center;\"><a href=\"paginas.php\">&lt;&lt; Voltar</a></p>";
		die();
	}
	$consulta_senha = mysql_query("SELECT * FROM usuarios WHERE senha = '$senha_atual'");
	if (mysql_num_rows($consulta_senha) == 0)
	{
		echo "<p style=\"text-align: center; font-weight: bold; font-family: arial, verdana, sans-serif; \">Senha errada.</p>";
		echo "<p style=\"text-align: center;\"><a href=\"paginas.php\">&lt;&lt; Voltar</a></p>";
		die();
	}
	if (mysql_query("UPDATE usuarios SET senha = '$senha_nova'"))
	{
		echo "<p style=\"text-align: center; font-weight: bold; font-family: arial, verdana, sans-serif; \">Senha alterada com sucesso!</p>";
		echo "<p style=\"text-align: center;\"><a href=\"paginas.php\">&lt;&lt; Voltar</a></p>";
		die();
	}
	else
	{
		echo "<p style=\"text-align: center; font-weight: bold; font-family: arial, verdana, sans-serif; \">Erro ao alterar senha. Tente novamente mais tarde.</p>";
		echo "<p style=\"text-align: center;\"><a href=\"paginas.php\">&lt;&lt; Voltar</a></p>";
		die();
	}
}
?>