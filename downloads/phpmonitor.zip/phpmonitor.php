<?php

/**
*
*
* PHmonitor - 0.1 - April, 23, 2011
*
* PHmonitor is a simple monitor that checks if a host is active.
*
* Angelito M. Goulart
*
* <angelito@bsd.com.br>
*
* Use: uses PHmonitor as a cronjob
*
*/



//log file (full path)

$log_file = 'status.log';



//hosts to be checks host=>port

$hosts  = array('google.com' => '80',

				'terra.com.br' => '80',

				'angelitomg.com' => '80');

	$fp = fopen($log_file, 'a');

	foreach($hosts as $host => $port)

	{

		$status = @fsockopen($host, $port, $err_nr , $err_str , 5);

		$date = date("F j, Y H:i:s");

		if ($status){

			$str = "Ok!    $host:$port  $date \r\n";

		} else {

			$str = "Error! $host:$port - $err_nr:$err_str  $date \r\n";

		}

		fwrite($fp, $str);

	}

	fclose($fp);

	

?>