//
//  DieDataController.h
//  OneDice
//
//  Created by Angelito M. Goulart on 16/04/14.
//  Copyright (c) 2014 Angelito M. Goulart. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DieDataController : NSObject
- (int) getDieNumber;
@end
