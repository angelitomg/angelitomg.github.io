<?php
$config = array(
	'Read' => 'value',
	'Deep' => array(
		'Deeper' => array(
			'Deepest' => 'buried'
		)
	),
	'TestAcl' => array(
		'classname' => 'Original'
	)
);
