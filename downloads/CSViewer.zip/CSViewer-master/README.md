CSViewer
==============

CSViewer is a CSV file viewer. Runs on command line and receives as parameters the name of a file and a delimiter. Shows each field of each line of the file on a separate line.

Usage
--------------

Call csviewer.rb passaing filename and delimiter as parameters. (default delimiter is blank character)

Example: csviewer.rb users.csv ;

Where users.csv is the file to be read and ';' is delimiter of each field of file.

License
--------------

This software is opensource and do not have any guarantee. You're free to use, modify and redistribute.


Author
--------------
Angelito M. Goulart

www.angelitomg.com
