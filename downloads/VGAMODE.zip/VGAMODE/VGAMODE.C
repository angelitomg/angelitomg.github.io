/**
 *
 * VGA.C - Exemplo de como utilizar o modo VGA em DOS.
 * Escreve 60.000 pixels de cores aleatorias em lugares aleatorios da tela
 * 
 * Angelito M. Goulart
 * www.angelitomg.com
 *
 * Janeiro/2013
 *
 */

#include <stdio.h>
#include <sys/nearptr.h>
#include <dos.h>
#include <time.h>
#include <stdlib.h>

// Define o tamanho da tela
#define SCREEN_SIZE 320

// Declaracao do tipo byte
typedef unsigned char byte;

// Ponteiro para manipular a tela
byte *VGA = (byte *) 0xA0000;

// Inicia o modo VGA
void init_vga()
{
        union REGS regs;
        regs.h.ah = 0x00;
        regs.h.al = 0x13;
        int86(0x10, &regs, &regs);
}

// Finaliza o modo VGA
void close_vga()
{
        union REGS regs;
        regs.h.ah = 0x00;
        regs.h.al = 0x03;
        int86(0x10, &regs, &regs);
}

// Funcao responsavel por escrever um pixel na tela. Recebe a posicao e a cor do pixel
void escrever_pixel(unsigned short posicao, byte cor)
{
        VGA[posicao] = cor;
}

// Funcao principal
int main()
{

        // Declaracao das variaveis necessarias
        unsigned short i, posicao, cor, posicao_x, posicao_y;

        // Diretiva necessaria do DJGPP
        VGA+= __djgpp_conventional_base;

        // Inicia o modo VGA
        init_vga();

        // Este programa vai escrever 60.000 pixels
        for(i = 0; i < 60000; i++)
        {

                // Calcula uma cor aleatoria
                cor = rand() % 256;

                // Calcula as posicoes aleatorias
                posicao_x = rand() % 320;
                posicao_y = rand() % 200;

                // Calcula a posicao exata de escrita do pixel
                posicao = posicao_y * 320 + posicao_x;

                // Chama a funcao que escreve o pixel na tela
                escrever_pixel(posicao, cor);

        }
        
        // Aguarda 10 segundos
        sleep(10);

        // Fecha o modo VGA e volta ao modo texto
        close_vga();

        return 0;

}
