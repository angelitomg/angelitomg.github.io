<?php
/*
* SaltWEB
* Angelito M. Goulart
* motor.php
* contem funcoes importantes para 
* o carregamento das paginas do site.
*/

require "admin/config.php";

/***** funcao que retorna o titulo do site *****/
function consultarTitulo()
{
	$consulta_titulo = mysql_query("SELECT titulo from configuracoes");
	$titulo_site = mysql_fetch_row($consulta_titulo);
	return $titulo_site[0];
}

/***** Funcao para gerar os atributos meta *****/
function geraMeta()
{
	global $pg_keywords;
	global $pg_descricao;
	$str_meta = "<meta name=\"keywords\" content=\"" . $pg_keywords . "\" /> \n";
	$str_meta .= "<meta name=\"description\" content=\"" . $pg_descricao . "\" /> \n";
	return $str_meta;
}

/***** funcao para gerar o topo do site *****/
function geraTopoSite()
{
	$str_topo = "<table>";
	$str_topo .= "<tr>";
	$str_topo .= "<td><a href=\"index.php\"><img src=\"logo.jpg\" /></a></td>";
	$str_topo .= "<td valign=\"bottom\"><h2>" . consultarTitulo() . "</h2></td>";
	$str_topo .= "</tr>";
	$str_topo .= "</table>";
	return $str_topo;
}

/***** Funcao para gerar o menu *****/
function geraMenuSite()
{
	$consulta_menu = mysql_query("SELECT nome, titulo FROM paginas");
	$str_menu = "<div id=\"menu\"><ul>";
	while ($menu = mysql_fetch_array($consulta_menu))
	{
		$str_menu .= "<li><a href=\"index.php?pag=" . $menu['nome'] . "\">" . $menu['titulo'] . "</a></li>";
	}
	$str_menu .= "</ul></div>";
	return $str_menu;
}

/***** Funcao para carregar a pagina *****/
function carregaPagina()
{
	global $pg_titulo;
	global $pg_keywords;
	global $pg_descricao;
	global $pg_conteudo;
	if(!$_GET['pag'])
	{
		$pag = '';
	}
	else
	{
		$pag = $_GET['pag'];
	}
	$sql_consulta_pagina = "SELECT * FROM paginas WHERE nome='$pag'";
	if (mysql_num_rows(mysql_query($sql_consulta_pagina)) == 0)
	{
		$pag = '';
	}
	if ($pag == '')
	{
		$consulta_carrega_pagina = mysql_query("SELECT * FROM paginas LIMIT 1");
	}
	else
	{
		$consulta_carrega_pagina = mysql_query("SELECT * FROM paginas WHERE nome = '$pag'");
	}
	if ($consulta_carrega_pagina)
	{
		while($pg = mysql_fetch_array($consulta_carrega_pagina))
		{
			$pg_titulo = $pg['titulo'];
			$pg_keywords = $pg['keywords'];
			$pg_descricao = $pg['descricao'];
			$pg_conteudo = $pg['conteudo'];
		}	
	}
	else
	{
		$pg_conteudo = "Erro ao carregar p&aacute;gina.";
	}
}

/***** Funcao para gerar o rodape *****/
function geraRodapeSite()
{
	$str_rodape = "<hr />";
	$str_rodape .= "<p class=\"rodape\">" . consultarTitulo() . " - Powered by <a href=\"http://orkadev.com\">OrkaDev</a></p>";
	return $str_rodape;
}

?>