<?php
require "autentica.php";
require "salt.php";
?>
<html>
<head>
<title>SaltWEB :: Excluir P&aacute;gina</title>
	<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
	<link href="style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php
	echo menuAdmin();
?>
<h2>Painel de Controle - Excluir P&aacute;gina</h2>

	<form action="corebd.php?op=3" method="post">
			<h3>Tem certeza de que deseja excluir a p&aacute;gina?</h3>
			<p class="big"><a href="corebd.php?op=3&pag=<?php echo $_GET['pag']; ?>">Sim</a>
			<a href="paginas.php">N&atilde;o</a></p>
	</form>
	<?php
		echo rodapeAdmin();
	?>
</body>
</html>