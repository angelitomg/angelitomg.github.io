<html>
<head>
	<title>SaltWEB :: Login</title>
</head>
<body>
<br /><br />
	<table align="center">
	<form name="login" action="efetua_login.php" method="POST">
		<tr>
			<td align="center" colspan="2"><img src="saltweb.jpg" alt="saltweb" /></td>
		</tr>
		<tr>
			<td>Usu&aacute;rio</td>
			<td><input type="text" name="usuario" maxlength="15" /></td>
		</tr>
		<tr>
			<td>Senha</td>
			<td><input type="password" name="senha" maxlength="15" /></td>
		</tr>
		<tr>
			<td align="center" colspan="2"><input type="submit" value="Efetuar Login" />
		</tr>
	</form>
	</table>
</body>
</html>