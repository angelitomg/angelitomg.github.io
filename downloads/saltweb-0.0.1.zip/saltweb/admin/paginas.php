<?php
require "autentica.php";
require "salt.php";
?>
<html>
<head>
<link type="text/css" href="style.css" rel="STYLESHEET" />
<title>SaltWEB :: Painel de Controle</title>
</head>
<body>
<?php
	echo menuAdmin();
?>
<h2>Painel de Controle - P&aacute;ginas</h2>
<a href="adicionar_pagina.php"><p>Nova P&aacute;gina</p></a>
<?php
	echo exibePaginas();
?>
<?php
	echo rodapeAdmin();
?>
</body>
</html>