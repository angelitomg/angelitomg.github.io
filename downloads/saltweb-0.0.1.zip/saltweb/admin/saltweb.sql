-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: Out 30, 2010 as 02:35 AM
-- Versão do Servidor: 5.1.41
-- Versão do PHP: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `saltweb`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `configuracoes`
--

CREATE TABLE IF NOT EXISTS `configuracoes` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Extraindo dados da tabela `configuracoes`
--

INSERT INTO `configuracoes` (`id`, `titulo`) VALUES
(1, 'SaltWEB');

-- --------------------------------------------------------

--
-- Estrutura da tabela `paginas`
--

CREATE TABLE IF NOT EXISTS `paginas` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `nome` varchar(20) NOT NULL,
  `titulo` varchar(25) NOT NULL,
  `keywords` varchar(200) NOT NULL,
  `descricao` text NOT NULL,
  `conteudo` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Extraindo dados da tabela `paginas`
--

INSERT INTO `paginas` (`id`, `nome`, `titulo`, `keywords`, `descricao`, `conteudo`) VALUES
(12, 'home', 'Home', 'pagina inicial, inicio, saltweb', 'pagina inicial de exemplo do saltweb', '<h1>\r\n	Bem-Vindo</h1>\r\n<p>\r\n	Obrigado por utilizar o SaltWEB. Para acessar o menu e come&ccedil;ar seu site, entre em http://URL_DO_SEU_SITE/admin. Logo ap&oacute;s, edite esta pagina ou crie uma nova de sua preferencia.&nbsp;</p>\r\n'),
(13, 'sobre', 'Sobre', 'sobre, sobre o saltweb, saltweb', 'sobre o saltweb', '<h1>\r\n	<span style="background-color: rgb(255, 240, 245); ">Sobre</span></h1>\r\n<p>\r\n	O SaltWEB &eacute; um CMS voltado a sites simples e rapidos. Seu foco &eacute; na facilidade e simplicidade. Para aprender mais sobre o SaltWEB, leia o arquivo INSTRUCOES, encontrado na raiz do diretorio do seu SaltWEB.</p>\r\n'),
(14, 'contato', 'Contato', 'contato, pagina de contato', 'pagina de contato', '<h1>\r\n	Contato</h1>\r\n<p>\r\n	Esta &eacute; uma p&aacute;gina de contato de exemplo. Para alterar o email que recebera as mensagens escritas na pagina de contato, altere o arquivo contato.php.</p>\r\n<form action="contato.php" method="POST" name="contato">\r\n	<p>\r\n		<strong>Nome</strong></p>\r\n	<p>\r\n		<input name="nome" type="text" /></p>\r\n	<p>\r\n		<strong>Email</strong></p>\r\n	<p>\r\n		<input name="email" type="text" /></p>\r\n	<p>\r\n		<strong>Assunto</strong></p>\r\n	<p>\r\n		<input name="assunto" type="text" /></p>\r\n	<p>\r\n		<strong>Mensagem</strong></p>\r\n	<p>\r\n		<textarea name="mensagem"></textarea></p>\r\n	<p>\r\n		<input type="submit" value="Enviar mensagem" /></p>\r\n</form>\r\n');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(15) NOT NULL,
  `senha` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `usuario`, `senha`) VALUES
(1, 'admin', '123');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
