#!/bin/bash
#####################
# Angelito M. Goulart
#
# 30 - Novembro/2009
#####################
user=''
pass=''
host=''
import -window root screen.jpg
ftp -n $host <<ENDSCRIPT
quote USER $user
quote PASS $pass
put screen.jpg
quit
ENDSCRIPT
rm -rf screen.jpg
