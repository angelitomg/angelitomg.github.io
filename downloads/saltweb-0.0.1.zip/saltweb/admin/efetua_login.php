<?php
/*
* Pagina de Login
* Angelito M. Goulart
*/
session_start();
if (isset($_SESSION['usuario']) && isset($_SESSION['senha']))
{
	header("location: index.php");
}
require "config.php";
$usuario = $_POST['usuario'];
$senha = $_POST['senha'];
$usuario = str_replace('\'','\\\'', $usuario);
$senha = str_replace('\'','\\\'', $senha);
$resultado = mysql_num_rows(mysql_query("SELECT usuario, senha FROM usuarios WHERE usuario = '$usuario' AND senha = '$senha'"));
if ( $resultado == 0)
{
	echo "<p style=\"text-align: center;\">Erro ao efetuar login!";
	echo "<br /><a href=\"login.php\">&lt;&lt; Voltar</a></p>";
}
else
{
		$_SESSION['usuario'] = $usuario;
		$_SESSION['senha'] = $senha;
		header("location: index.php");
}

?>