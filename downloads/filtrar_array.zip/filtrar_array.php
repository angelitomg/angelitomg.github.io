<?php

	/**
	 *
	 * filtrar_array.php
	 * 
	 * Script utilizado para mostrar como percorrer todos os elementos
	 * de um array e aplicar uma funcao de filtro a todos os elementos.
	 *
	 * Angelito M. Goulart
	 *
	 * 05/03/2013
	 *
	 */
	
	// Array de teste
	$_POST = array(
		'cliente' => array(
			'nome' => '<script></script>',
			'dados_bancarios' => array(
				'conta' => 'javascript',
				'banco' => 'BANCO'
			)
		),
		'compra' => 'javascript',
		'data' => '01/01/01'
	);

	// Funcao responsavel por filtrar os dados
	function filtrar_dados(&$valor, &$chave)
	{

		// Aqui voce pode colocar qualquer codigo que voce deseja que seja aplicado a cada elemento do array, 
		// ja que todos os elementos do array passarao por essa funcao.

   		//Array com palavras nao permitidas
		$filtros = array('javascript', '<script>', '</script>', 'script', 'onclick', 'onsubmit', 'script', 'onmouseover');
	
		// Limpa a string das palavras nao permitidas
		$valor = str_ireplace($filtros, '', $valor);
	}

	// Exibicao do array cru
	echo '<h3>Array Cru</h3>';
	print_r($_POST);


	// Aplicacao da funcao de filtro a todos os elementos do array
	array_walk_recursive($_POST, 'filtrar_dados');

	// Exibicao do array limpo
	echo '<h3>Array Filtrado</h3>';
	print_r($_POST);

?>