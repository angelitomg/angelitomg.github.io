<?php
	
	/**
 	 * Exemplo do uso de traits
 	 * Angelito M. Goulart
	 * www.angelitomg.com
	 * 20/12/2012
	 */

	// Criacao do trait
	trait HelloWorld{
		
		// Metodos que o trait ira conter
		function display() { echo 'Hello World!'; }

	}
	
	// Criacao da classe que usara o trait
	class AloMundo{

		// Chamada ao trait criado anteriormente
		use HelloWorld;

	}
	
	// Criacao do objeto da classe AloMundo
	$obj = new AloMundo();

	// Chamada do metodo display, presente no trait HelloWorld,
	// chamado atraves da classe AloMundo, que usa o trait HelloWorld
	$obj->display();

?>

