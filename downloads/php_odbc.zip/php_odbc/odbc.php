<?php
	
	/**
	*
	* odbc.php
	*
	* Exemplo de conexao com banco de dados via ODBC com PHP
	*
	* Banco de dados: banco.mdb
	*
	* Tabela: regioes
	*
	* Campos: Codigo, Regiao
	*
	* Angelito M. Goulart
	*
	* www.angelitomg.com
	*
	* 10/04/2012
	*
	*/
	
	/** 
	* Define o buffer de conexoes ODBC para que seja possivel trabalhar 
	* com campos com muitos dados 
	*/
	ini_set('odbc.defaultlrl', '65536');
	
	/* Realiza a conexao com o banco de dados atraves da DSN db_regioes */
	$conexao = odbc_connect("db_regioes", "", "");
	
	/* SQL de consulta das regioes */
	$sql = "SELECT * FROM regioes ORDER BY Regiao";

	/* Realiza a consulta no banco de dados */
	$consulta = odbc_exec($conexao, $sql);
	
	/* Percorre os resultados da consulta */
	while ($resultado = odbc_fetch_array($consulta)){
	
		/* Exibe cada regiao encontrada */
		echo '<p>' . $resultado['Regiao'] . '</p>';
		
	}
	
	/* Fecha a conexao */
	odbc_close($conexao);
	
?>