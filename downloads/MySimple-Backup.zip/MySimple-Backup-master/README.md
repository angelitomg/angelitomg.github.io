MySimple Backup 
==============
 
Versao 1.0  
Agosto/2012  

Estrutura
--------------

images/    -> imagens utilizadas no sistema.  
css/ 	   -> arquivos css utilizados no layout do sistema.  
index.php  -> formulario de insercao dos dados.  
backup.php -> arquivo responsavel por realizar o backup da base de dados.  

Descricao
--------------

Script responsavel por realizar o backup de uma base dados do MySQL. 

Instalacao
--------------

Copie a pasta do programa para uma pasta dentro da raiz do seu sevidor web. 

Uso
--------------

Acesse o diretorio do programa, depois de devidamente instalado, acesse o arquivo index.php.  

Informe os dados da base de dados e clique em Backup. Um arquivo com o dump da base de dados sera enviado para download.

Licenca
--------------

Este e um software livre, pode ser redistribuido, modificado e nao possui nenhuma garantia.

Autor
--------------

Angelito M. Goulart

www.angelitomg.com

