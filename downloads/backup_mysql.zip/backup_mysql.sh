#!/bin/bash
#Angelito M. Goulart - Setembro/2009
#backup de todas as  bases de dados do MySQL
mysqldump -u root -p12345 --all-databases > /home/angelito/backup_$(date +%d%m%Y).sql
