<?php
	
	/**
	 *
	 * Exemplo de como obter a diferenca entre duas datas com PHP
	 *
	 * Angelito M. Goulart
	 *
	 * www.angelitomg.com
 	 *
	 * 19/12/2012
	 *
	 */

	// Criacao das datas
	$data_inicial = \DateTime::createFromFormat('Y-m-d', '2012-12-19');
	$data_final   = \DateTime::createFromFormat('Y-m-d', '2012-12-31');
	
	// Calculo da diferenca entre as datas
	$diferenca = $data_final->diff($data_inicial);
	
	// Exibicao da diferenca
	echo 'Diferenca em meses -> ' . $diferenca->format("%m meses %d dias!");
	echo '<br />';
	echo 'Diferenca em dias  -> ' . $diferenca->format("%a dias!");


?>
