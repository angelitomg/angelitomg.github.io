<?php

	/**
	*
	* @funcao: gerarSenha
	*
	* @descricao: funcao responsavel por gerar uma senha 
	* alfanumerica aleatoria. Recebe como parametro o tamanho 
	* da senha a ser gerada e retorna a senha gerada. Se nao for
	* informado nenhum parametro, sera gerada uma senha de 6 caracteres.
	*
	* @autor: Angelito M. Goulart <angelito@bsd.com.br>
	*
	* @data: 30/05/2012
	*
	*/
	function gerarSenha($tamanho = 6){
		
		/* Caracteres permitidos */
		$caracteres = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
		
		/* Quantidade de indices que o array caracteres tem */
		$maximo = strlen($caracteres) - 1;
		
		/* Inicializa a variavel que ira conter a senha */
		$senha = '';
		
		/* Percorre o loop de acordo com o tamanho da senha */
		for($i = 0; $i < $tamanho; $i++){
		
			/* Pega uma posicao aleatoria do array de caracteres */
			$posicao_aleatoria = mt_rand(0, $maximo);
			
			/* Obtem o caracterer da posicao aleatoria gerada anteriormente e adiciona a senha */
			$senha .= $caracteres[$posicao_aleatoria];
			
		}
		
		/* Retorna a senha gerada */
		return $senha;
		
	}

?>