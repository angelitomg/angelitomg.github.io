<?php
$servidor = "localhost";
$usuario = "admin";
$senha = "1234";
$banco = "saltweb";
if (!(mysql_connect($servidor, $usuario, $senha)) || !(mysql_select_db($banco)))
{
	echo "Erro ao se conectar a base de dados!" . "<br />";
	die();
}
?>