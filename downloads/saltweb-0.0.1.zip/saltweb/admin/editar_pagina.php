<?php
require "autentica.php";
require "salt.php";
?>
<?php

	consultarPagina();
?>
<html>
<head>
<title>SaltWEB :: Editar P&aacute;gina</title>
	<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
	<link href="style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php
	echo menuAdmin();
?>
<h2>Painel de Controle - Editar P&aacute;gina</h2>
<div id="alerts">
		<noscript>
			<p>
				<strong>Seu navegador est&aacute; com o JavaScript desabilitado. Habilite e tente novamente.</strong>
			</p>
		</noscript>
	</div>
	<form action="corebd.php?op=2&pag=<?php echo $_GET['pag']; ?>" method="post">
			<p><label class="negrito">Nome</label><br />
			<input type="text" value="<?php echo $nome_pagina; ?>" name="nome" /><span class="small"> (sem espa&ccedil;os)</span></p>
			<p><label class="negrito">T&iacute;tulo</label><br />
			<input type="text" value="<?php echo $titulo_pagina; ?>" name="titulo" /></p>
			<p><label class="negrito">Palavras-Chave</label><br />
			<input type="text" value="<?php echo $keywords_pagina; ?>" name="keywords" /><span class="small"> (separadas por v&iacute;gula)</span></p>
			<p><label class="negrito">Descri&ccedil;&atilde;o</label><br />
			<textarea name="descricao" cols="50" rows="4"><?php echo $descricao_pagina; ?></textarea></p>
			<h3>Conte&uacute;do</h3>
			<textarea cols="80" id="conteudo" name="conteudo" rows="10"><?php echo $conteudo_pagina; ?></textarea>
			<script type="text/javascript">
			//<![CDATA[

				// This call can be placed at any point after the
				// <textarea>, or inside a <head><script> in a
				// window.onload event handler.

				// Replace the <textarea id="editor"> with an CKEditor
				// instance, using default configurations.
				CKEDITOR.replace( 'conteudo' );

			//]]>
			</script>
		</p>		<p>
			<input type="submit" value="Alterar P&aacute;gina" />
			<input type="reset" value="Limpar Tudo" />
	</form>
	<?php
		echo rodapeAdmin();
	?>
</body>
</html>