<?php
header("location: paginas.php");
?>