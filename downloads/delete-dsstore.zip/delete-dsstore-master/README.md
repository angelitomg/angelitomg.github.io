delete-dsstore
==========

A simple python script to delete .DS_Store files

usage
----------
Call the script passing as parameter the directory you want to remove the .DS_Store files

Attention: This script works recursively

license
----------
This script is free and you can modify and distribute without any restriction. And without any warranty.

author
----------
Angelito M. Goulart

www.angelitomg.com
