<?php
require "autentica.php";
require "salt.php";
?>
<html>
<head>
<link type="text/css" href="style.css" rel="STYLESHEET" />
<title>SaltWEB :: Painel de Controle</title>
</head>
<body>
<?php
	echo menuAdmin();
?>
<h2>Painel de Controle - Configura&ccedil;&otilde;es</h2>
<form name="titulo" action="corebd.php?op=4" method="POST">
<p class="negrito">T&iacute;tulo<br />
<input type="text" value="<?php echo consultarTitulo(); ?>" name="titulo" maxlength="20" />
</p>
<input type="submit" value="Alterar T&iacute;tulo" />
</form>
<form name="alterar_senha" action="corebd.php?op=5" method="POST">
<p class="negrito">Senha atual<br />
<input type="password" name="senha_atual" maxlength="15" />
</p>
<p class="negrito">Nova Senha<br />
<input type="password" name="senha_nova" maxlength="15" />
</p>
<p class="negrito">Repetir Senha<br />
<input type="password" name="senha_nova2" maxlength="15" />
</p>
<input type="submit" value="Alterar Senha" />
</form>
<?php
	echo rodapeAdmin();
?>
</body>
</html>