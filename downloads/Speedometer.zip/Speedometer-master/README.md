# Speedometer

- A simple digital speedometer for iOS.

- Can use multiple measure units.

- Saves the highest speed and the location where the speed has been reached.

- Developed for iOS 9.

## Author
[Angelito Goulart](http://angelitomg.com/)
