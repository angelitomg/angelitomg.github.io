<?php

	/*-----------------------------------------------------------
	*
	* @nome: verificaEmail
	*
	* @descricao: Funcao para verificar se um email e valido
	* retorna TRUE se o email for valido e FALSE se for invalido
	*
	* @autor: Angelito M. Goulart
	*
	* @data: 13/10/2011
	*
	*-----------------------------------------------------------*/
	function verificaEmail($email){

		/* Verifica se o email e valido */
		if (filter_var($email, FILTER_VALIDATE_EMAIL)){
			
			/* Obtem o dominio do email */
			list($usuario, $dominio) = explode('@', $email);
			
			/* Faz um verificacao de DNS no dominio */
			if (checkdnsrr($dominio, 'MX') == 1){
				return TRUE;
			} else {
				return FALSE;
			}
			
		} else {
			return FALSE;
		}
	}
	
?>