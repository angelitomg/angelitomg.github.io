<?php
	
	function getPaises(){
		$paises = array('Brasil', 'China', 'Costa Rica', 'Dinamarca', 'Egito');
		for ($i = 0; $i < sizeof($paises); $i++){
			yield $paises[$i];
		}
	}

	foreach (getPaises() as $pais) {
		echo "<p>{$pais}</p>";
	}	

?>